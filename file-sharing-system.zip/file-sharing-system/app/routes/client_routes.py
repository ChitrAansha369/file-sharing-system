from flask import Blueprint, request, jsonify, send_from_directory
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.utils.encryption import generate_download_token, verify_download_token
from app.models import File
from app import db
import os

client_bp = Blueprint('client', __name__)

UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')

@client_bp.route('/files', methods=['GET'])
@jwt_required()
def list_files():
    identity = get_jwt_identity()
    if identity['role'] != 'client':
        return jsonify({"error": "Access denied"}), 403

    files = File.query.all()
    result = []
    for f in files:
        token = generate_download_token(f.filename)
        result.append({
            "filename": f.filename,
            "download_url": f"/client/download?token={token}"
        })

    return jsonify(result), 200

@client_bp.route('/download', methods=['GET'])
@jwt_required()
def download_file():
    identity = get_jwt_identity()
    if identity['role'] != 'client':
        return jsonify({"error": "Access denied"}), 403

    token = request.args.get('token')
    if not token:
        return jsonify({"error": "Missing token"}), 400

    filename = verify_download_token(token)
    if not filename:
        return jsonify({"error": "Invalid or expired token"}), 403

    return send_from_directory(UPLOAD_FOLDER, filename, as_attachment=True)
