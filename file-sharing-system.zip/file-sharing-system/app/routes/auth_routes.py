from flask import Blueprint, request, jsonify
from app import db, bcrypt
from app.models import User
from flask_jwt_extended import create_access_token

auth_bp = Blueprint('auth', __name__)

@<your_bp>.route('/ping')
def ping():
    return jsonify({"message": "pong"}), 200


@auth_bp.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    
    if not data or 'email' not in data or 'password' not in data:
        return jsonify({"error": "Email and password are required"}), 400

    if User.query.filter_by(email=data['email']).first():
        return jsonify({"error": "User already exists"}), 409

    hashed_password = bcrypt.generate_password_hash(data['password']).decode('utf-8')
    new_user = User(email=data['email'], password=hashed_password, role='client')

    db.session.add(new_user)
    db.session.commit()

    return jsonify({"message": "Client user registered successfully"})


@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()

    if not data or 'email' not in data or 'password' not in data:
        return jsonify({"error": "Email and password are required"}), 400

    user = User.query.filter_by(email=data['email']).first()

    if not user or not bcrypt.check_password_hash(user.password, data['password']):
        return jsonify({"error": "Invalid credentials"}), 401

    # 🔽 THIS IS THE IMPORTANT LINE
    access_token = create_access_token(identity={"id": user.id, "role": user.role})

    return jsonify({
        "message": f"{user.role.capitalize()} login successful",
        "access_token": access_token
    }), 200

