 
from itsdangerous import URLSafeTimedSerializer
import os

secret_key = os.getenv("SECRET_KEY", "defaultsecret")
serializer = URLSafeTimedSerializer(secret_key)

def generate_download_token(filename):
    return serializer.dumps(filename)

def verify_download_token(token, max_age=3600):
    try:
        return serializer.loads(token, max_age=max_age)
    except Exception:
        return None
